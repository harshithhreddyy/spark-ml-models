# Spark ML Models

This repository contains three Spark-based machine learning models built using PySpark on Google Colab:

1. **Classification** - Predicting diabetes using the Pima Indians dataset.
2. **Clustering** - Customer segmentation using Mall Customers dataset.
3. **Recommendation** - Movie recommendation system using MovieLens dataset.

## How to Use

- Open each `.ipynb` notebook in [Google Colab](https://colab.research.google.com/)
- Make sure you upload the datasets to your Colab environment before running the cells.

## Datasets

Place all datasets under a folder named `datasets/` in your Colab environment or modify paths as needed.
